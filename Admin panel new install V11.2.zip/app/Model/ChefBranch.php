<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ChefBranch extends Model
{
    protected $table = 'chef_branch';
}

<?php

const APPS = [
    'table_app' => [
        'software_id' => 40488202,
        'app_name' => 'Efood table app',
        'buy_now_link'=>'https://codecanyon.net/item/efood-tablewaiter-app/40488202?s_rank=2'
    ],
    'kitchen_app' => [
        'software_id' => 40488338,
        'app_name' => 'Efood kitchen app',
        'buy_now_link'=>'https://codecanyon.net/item/efood-kitchenchef-app/40488338?s_rank=1'
    ],
];
